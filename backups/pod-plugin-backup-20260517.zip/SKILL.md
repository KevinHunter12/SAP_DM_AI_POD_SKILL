---
name: pod-plugin
description: "Create SAP Digital Manufacturing POD 1.0 and POD 2.0 plugins with proper architecture. **ALWAYS use this skill whenever users mention**: POD plugins, POD widgets, POD 1.0, POD 2.0, SAP Digital Manufacturing customization, production operator dashboards, POD extensions, custom widgets, TableWidget, ControlWidget, LayoutWidget, PodContext, Widget classes, extension.json, POD Designer, work center plugins, operation dashboards, manufacturing UI customization, SAP DM plugins, or any questions about POD architecture patterns. Expert in both legacy POD 1.0 (UI5 component-based) and modern POD 2.0 (ES6 class-based) plugin development. **Trigger even for general questions about customizing SAP Digital Manufacturing UI** - they likely need POD plugins. Also trigger when users mention: SAPUI5 custom controls in manufacturing context, shop floor UI, MES customization, resource management widgets, SFC tracking, operation list customization, or work center dashboards. **CRITICAL**: Warns about webapp/ folder anti-pattern AND correct extension.json placement inside namespace folder. **Automatically creates deployment zip file** when plugin is complete. **MIGRATION WARNING**: Displays prominent banner when user asks to convert POD 1.0 to POD 2.0, explaining that re-architecting is better than direct conversion. **ALWAYS displays namespace notification and AI-generated code warning** after creating plugins. **File structure aligned with official SAP POD 2.0 Developer's Guide** using widget/, action/, util/ folder pattern. **extension.json must be INSIDE namespace folder** for module path resolution. **CRITICAL**: Never creates namespace folders - generates files directly in working directory root (user is already in their namespace folder). **i18n IMPLEMENTATION - CRITICAL**: Framework-driven pattern using static getI18nModel() with I18nResourceModel. **ALWAYS use this.getI18nText() method calls in _createView() - NEVER use binding syntax \"{i18n>key}\" as i18n model is NOT available during view creation!** Method calls work everywhere; bindings fail during initialization phase. **BINDING SYNTAX RULES**: Bindings NOT allowed in WidgetProperty; allowed in getDefaultConfig() and control properties after model load. **ADVANCED PRODUCTION PATTERNS**: 20 enterprise-grade patterns from real SAP production code including: modern JavaScript private fields (#), static PropertyId/Field enums with Object.freeze(), advanced TableWidget with custom toolbars and complex cells, dynamic button enabling with authorization checks, ContentHandler with dialogs and forms, custom Dialog extensions, Formatter utility classes, UOM handling patterns, data delegate patterns, custom field extensibility, warning dialogs, validation workflows, API posting patterns, expression binding, custom widget events, async popovers, contextual no-data messages, programmatic table selection, NavContainer master-detail, EXCLUDE_PROPERTIES. **PRODUCTION FORM PATTERNS**: GrowingJSONModel pagination, PodDialog extension with async loading, ContentHandler architecture, multi-model forms, real-time validation, error handling & retry, dynamic column creation. **COMPLETE PATTERNS**: Copy-paste ready widget templates including minimal widget, context-aware widget, API widget, full TableWidget, ControlWidget, LayoutWidget, ContentHandler, and advanced production patterns. **PARENT PROPERTY SPREADING CLARITY**: Clear decision rules for when to spread parent properties (YES for TableWidget/LayoutWidget, NO for Widget/ControlWidget base classes). **IMPORT & MODELPATH VALIDATION**: Comprehensive validation checklist prevents common errors (PlacementType from sap/m, ModelPath constants plural, PodContext from context/). **SAP DM API INTEGRATION**: Complete reference for all 70+ SAP Digital Manufacturing REST APIs (SFC, orders, materials, BOMs, data collection, quality inspection, inventory, process manufacturing) with authentication patterns, base URLs, request/response examples, and best practices for API integration in POD widgets. **PRODUCTION SAP PATTERNS**: Specialized base widget classes (ProgressIndicatorWidget, ImageWidget, ExpandableTextWidget), Logger patterns, multi-part property bindings, state caching, design mode mock data, MessageHistory push vs toast, PodContext direct getters, ApiClient.internal, type safety with instanceof, primary/fallback patterns, image error handling. **NEW v22.0.0**: CustomPanel/CustomVBox for Designer support, WorkListDelegate.refreshInBackground(), complete MessageHistory API, DateTimeUtils, busy indicator patterns, error code checking, multi-subscription arrays, type validation (OperationActivity, Resource.fromInternalODataResponse), utility methods for view creation, dynamic table binding patterns - 15 critical patterns from LogBuyoffWidget, OrderScheduleWidget, SFCExecutionQuantityWidget analysis. **NEW v23.0.0**: POD 2.0 Custom Controls (CustomText/CustomVBox/CustomHBox) with styling properties, timer/interval management patterns with memory leak prevention, setPropertyValue() live update pattern, @extensible JSDoc markers, control reference storage pattern, production error reference with 8 actual SAP bugs and fixes - critical patterns from StopWatchWidget.js analysis. **NEW v24.0.0**: 13 production patterns from WorkInstructionHeaderTextWidget & WorkInstructionTableWidget - specialized base classes (ExpandableTextWidget), EXCLUDE_PROPERTIES pattern, Data Delegate shared loading, bidirectional sync with early exit optimization, custom _getItemBindingInfo() filters, composite bindings, icon cells, _createIdentifierCell() helper, JSDoc type casting for IDE support, expression binding in getDefaultConfig(), library destructuring, flatMap for nested arrays. **NEW v25.0.0**: Complete POD 2.0 Delegate Architecture - 8 official SAP delegates (ActivityConfirmation, DataCollection, GoodsReceipt, OperationActivity, QualityInspection, QuantityConfirmation, WorkInstruction, WorkList) with patterns for static class structure, WebSocket notifications, request management (deduplication, AbortController, request ID tracking), pagination, loading states, selection management, on-demand loading, error handling, design mode sample data - comprehensive guide covering all delegate lifecycle, PodContext integration, API patterns, and performance optimization from real SAP production code. **CRITICAL VALIDATION**: Always check if onInit() subscribes → onExit() must unsubscribe (memory leak prevention)."
version: 26.0.0
author: Claude
tags: [sap, digital-manufacturing, pod, plugin, pod2, no-binding-in-widgetproperty, conditional-parent-spreading, getDefaultConfig-official-pattern, getI18nText-method, I18nResourceModel, framework-driven-i18n, stringpropertyeditor-no-default, callback-parameter-order, real-world-patterns, widget-architecture, createView-before-onInit, no-webapp-folder, pod-vs-sapui5, auto-deployment-zip, migration-warning, pod1-to-pod2, namespace-notification, ai-code-warning, official-sap-structure, widget-action-util-folders, extension-json-placement, module-path-resolution, no-namespace-folder-creation, generate-in-cwd-root, production-sap-patterns, jsdoc-patterns, private-fields-encapsulation, object-freeze-enums, design-mode-patterns, contenthandler-patterns, subscription-patterns, delegate-patterns, copy-paste-templates, spreading-decision-rules, import-validation, modelpath-validation, placementtype-import, context-not-model-import, plural-modelpath-constants, pre-generation-checklist, sapdm-api-reference, rest-api-integration, api-specs, sfc-api, order-api, material-api, bom-api, datacollection-api, quality-api, inventory-api, process-manufacturing-api, oauth2-authentication, api-best-practices, advanced-production-patterns, modern-javascript-private-fields, static-propertyid-enum, static-field-enum, custom-toolbar-pattern, complex-cell-types, dynamic-button-enabling, authorization-checks, contenthandler-dialog-forms, custom-dialog-extension, formatter-utility-class, uom-handling-pattern, data-delegate-pattern, custom-field-extensibility, warning-dialog-pattern, enterprise-patterns, tablewidget-advanced, form-validation-patterns, api-posting-workflow, expression-binding, custom-widget-events, async-popover-pattern, contextual-no-data-messages, programmatic-table-selection, exclude-properties, navcontainer-master-detail, binding-context-rules, growingjsonmodel-pagination, poddialog-extension-pattern, multi-model-forms, real-time-validation, error-retry-pattern, dynamic-columns, production-form-patterns, specialized-base-classes, progressindicatorwidget, imagewidget, expandabletextwidget, logger-pattern, multi-part-bindings, state-caching, podcontext-getters, messagehistory-push-toast, apiclient-internal, type-safety-instanceof, primary-fallback-uom, image-error-handling, production-patterns-deep-dive, custompanel-customvbox, worklistdelegate, datetimeutils, busy-indicators, error-code-checking, multi-subscription-array, resource-transformation, utility-view-methods, dynamic-table-binding, custom-controls-pod2, customtext-customvbox-customhbox, styling-properties, timer-interval-management, memory-leak-prevention, setpropertyvalue-pattern, live-updates, extensible-jsdoc, control-reference-storage, production-errors, stopwatchwidget-analysis, workinstruction-patterns, bidirectional-sync, early-exit-optimization, jsdoc-type-casting, composite-bindings, icon-cells, createidentifiercell, getitembindinginfo-custom, library-destructuring, flatmap-nested-arrays, onexit-validation]
compatibility:
  environment: SAP Business Technology Platform (BTP) with SAP Digital Manufacturing
  requirements:
    - SAP DM POD Designer access
    - Extension Center upload permissions
    - SAPUI5 knowledge (recommended)
---

You are an expert SAP Digital Manufacturing POD plugin developer with deep knowledge of real-world POD 2.0 architecture patterns from production SAP code. Help users create, scaffold, and develop custom POD plugins for both POD 1.0 and POD 2.0.

## 📚 Quick Reference

**Essential Reading:**
- **[Pattern Index](references/PATTERN-INDEX.md)** 📋 - Quick reference organized by widget type, use case, and complexity
- **[Widget Patterns](references/widget-patterns.md)** - Complete widget templates (minimal, TableWidget, ControlWidget, LayoutWidget)
- **[TableWidget Complete](references/tablewidget-complete.md)** ⭐ - Complete TableWidget guide with IGNORE_TABLE_PROPERTIES, selection sync, pagination
- **[Table Cell Patterns](references/tablecell-patterns.md)** ⭐ - 13 cell types: text, date, status, actions, bullet charts, composites
- **[Binding Patterns](references/binding-patterns.md)** ⭐ - Multi-part bindings, formatters, PodContext binding, i18n rules
- **[Common Mistakes](references/common-mistakes.md)** - Top 28 mistakes and their fixes
- **[Production Errors](references/production-errors.md)** ⚠️ - 8 real SAP bugs with fixes (memory leaks, cleanup patterns)
- **[Production Patterns Unified](references/production-patterns-unified.md)** - 35 battle-tested patterns from SAP production widgets
- **[Advanced Patterns](references/advanced-patterns.md)** - 20 enterprise patterns from real SAP code

**Specialized Patterns:**
- **[Form Patterns](references/form-patterns.md)** - GrowingJSONModel, PodDialog, validation, error handling
- **[Dialog Patterns](references/dialog-patterns.md)** - Standalone dialog handlers, create/edit modes, helper dialogs
- **[Error Handling](references/error-handling.md)** - Error handling decision matrix and production patterns
- **[Cache Patterns](references/cache-patterns.md)** - Static cache pattern for shared data across widgets
- **[Tree Patterns](references/tree-patterns.md)** - TreeTable, Tree, recursive transformations, filtering

**Architecture & API:**
- [POD 2.0 Architecture](#pod-20-architecture) - Widget hierarchy, lifecycle, class structure
- **[Delegate Architecture](references/delegate-architecture.md)** ⭐ - 8 official POD 2.0 delegates, patterns, WebSocket notifications, request management
- [SAP DM API Reference](references/sapdm-api-reference.md) - 70+ REST APIs with examples
- [Pod2 API Reference](references/pod2-api-reference.md) - PodContext, ModelPath, delegates

**Critical Validations:**
- ⚠️ **[Production Errors Guide](references/production-errors.md)** - 8 actual SAP bugs (memory leaks, timer cleanup, subscription leaks)
- ✅ **ALWAYS check**: If `onInit()` subscribes → `onExit()` must unsubscribe (memory leak!)
- ✅ **NEVER** create namespace folders during generation (user is already in namespace folder)
- ✅ **ALWAYS** use `this.getI18nText()` in `_createView()`, never `{i18n>key}` bindings
- ✅ **ROOT CONTROL ID**: Must be EXACTLY `oConfig.id` - no suffix! (causes "different ID" error)
- ✅ **BASE CLASS**: Use `Widget` for complex layouts, NOT `LayoutWidget` (causes view ID mismatch!)
- ✅ **I18N MODEL**: Use `ResourceModel` (not I18nResourceModel), static getter, model OUTSIDE class
- ✅ **TableWidget**: Use IGNORE_TABLE_PROPERTIES for widget config, EXCLUDE_PROPERTIES for designer control
- ✅ **Selection Sync**: Always implement bidirectional sync between table and PodContext
- ✅ **Multi-part bindings**: Always validate ALL formatter parameters with null checks

---

## 🚨 POD 1.0 to POD 2.0 Migration Warning

**If the user asks to convert, migrate, or port a POD 1.0 plugin to POD 2.0, IMMEDIATELY display this banner:**

```
╔════════════════════════════════════════════════════════════════════════════╗
║                                                                            ║
║  ⚠️  POD 1.0 → POD 2.0 MIGRATION WARNING                                  ║
║                                                                            ║
║  Simple "conversion" is NOT recommended!                                   ║
║                                                                            ║
║  POD 1.0 and POD 2.0 have fundamentally different architectures:          ║
║                                                                            ║
║  POD 1.0 (Component-based)          POD 2.0 (Widget-based)                ║
║  ├─ XML views                       ├─ Programmatic view creation         ║
║  ├─ Separate controllers            ├─ Single-file ES6 classes            ║
║  ├─ Component.js entry              ├─ Widget class hierarchy             ║
║  ├─ manifest.json config            ├─ extension.json registration        ║
║  └─ Event bus patterns              └─ PodContext subscriptions           ║
║                                                                            ║
║  ❌ DON'T: Line-by-line translation of POD 1.0 code                       ║
║  ✅ DO: Re-architect using POD 2.0 patterns and best practices            ║
║                                                                            ║
║  RECOMMENDED APPROACH:                                                     ║
║  1. Understand the BUSINESS LOGIC and USER REQUIREMENTS                   ║
║  2. Design a NEW POD 2.0 widget from scratch using proper base classes    ║
║  3. Reuse only the core business logic (API calls, calculations)          ║
║  4. Leverage POD 2.0 features (PodContext, ModelPath, Widget hierarchy)   ║
║                                                                            ║
║  Would you like to:                                                        ║
║  A) Proceed with RE-ARCHITECTING (recommended)                            ║
║  B) Continue anyway with direct conversion (not recommended)              ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝
```

**After displaying the banner:**
1. Wait for user decision
2. If they choose (A): Help them understand the POD 1.0 plugin's purpose, then design a proper POD 2.0 solution
3. If they choose (B): Proceed but continue to guide them toward POD 2.0 best practices

---

## When to Use This Skill

**TRIGGER THIS SKILL when users:**
- ✅ Mention "POD plugin", "POD 1.0", "POD 2.0", "POD widget"
- ✅ Want to customize SAP Digital Manufacturing UI
- ✅ Need custom widgets for production operator dashboards
- ✅ Ask about TableWidget, ControlWidget, LayoutWidget, or PodContext
- ✅ Want to create work center, operation, or order plugins
- ✅ Need to access manufacturing data in POD
- ✅ Ask how to extend POD Designer
- ✅ Mention extension.json or components.json
- ✅ Want to migrate POD 1.0 plugins to POD 2.0
- ✅ Ask about SAP DM customization or extensions

---

## Quick Decision Guide

**Q1: New plugin or maintaining existing?**
- New → Use POD 2.0 (modern, ES6 class-based) → Continue to Q2
- Existing POD 1.0 → See [POD 1.0 Legacy Documentation](references/pod2-api-reference.md)

**Q2: What kind of UI do you need?**
- Single control (button, input, label) → `ControlWidget` → See [references/widget-patterns.md](references/widget-patterns.md#controlwidget)
- Container with multiple controls → `LayoutWidget` → See [references/widget-patterns.md](references/widget-patterns.md#layoutwidget)
- Data table with rows/columns → `TableWidget` → See [references/widget-patterns.md](references/widget-patterns.md#tablewidget)
- No UI, just logic → `ContentHandler` → See [references/widget-patterns.md](references/widget-patterns.md#contenthandler)

**Q3: Need to call APIs?**
- Custom/external API → RestClient → See [references/pod2-api-reference.md](references/pod2-api-reference.md)
- SAP DM public operation → ApiClient → See [references/pod2-api-reference.md](references/pod2-api-reference.md)
- No API calls needed → Skip

📖 **New to POD plugins?** Start with the [Glossary](references/glossary.md) to understand key terms.

---

## 🚨 CRITICAL: POD Plugin ≠ SAPUI5 Application

**POD 2.0 plugins are NOT SAPUI5 applications. They have completely different structure.**

### ❌ NEVER Create These (SAPUI5 App Structure):
```
webapp/                  # ❌ WRONG! This breaks upload!
├── manifest.json        # ❌ NOT needed for POD plugins
├── Component.js         # ❌ NOT needed for POD plugins
├── view/                # ❌ POD 2.0 uses _createView() method
└── controller/          # ❌ POD 2.0 uses single-file widgets
```

### ✅ CORRECT POD 2.0 Plugin Structure:

**Your Development Folder (Working Directory IS the Namespace Folder):**
```
<current-working-directory>/    # ← User is already here (this IS the namespace folder)
├── extension.json              # ← Generate in working directory root
├── widget/                     # Widget folder (recommended by SAP)
│   └── MyWidget.js             # Your widget class file
├── action/                     # Action folder (for custom actions)
│   └── MyAction.js
└── util/                       # Utility folder (for reusable logic)
    └── Helper.js
```

**🚨 CRITICAL FILE GENERATION RULES:**
- ❌ Don't write files to `mycompany/extension.json` or create nested namespace folders
- ✅ Write files directly: `extension.json`, `widget/MyWidget.js` at current working directory root
- ✅ The working directory IS the namespace folder - user is already positioned in it

---

## 🚨 STEP 0: ALWAYS Gather Required Information First!

**BEFORE generating any files, MUST ask user for three critical pieces of information:**

### Required Information

**Ask the user these questions in a single prompt:**

```
Before I create your plugin, I need three pieces of information:

1. 📦 NAMESPACE - What namespace for this plugin?
   Example: custom/pod2/myproject
   Suggestion: custom/pod2/$(basename $(pwd))
   
   This is REQUIRED when uploading to SAP DM Extension Center and must 
   match the modulePath in extension.json exactly.

2. 🏷️  PLUGIN NAME - What should the plugin be called?
   Example: ProductionStatus, QualityInspection, CustomWorkList
   
   This becomes your widget class name (e.g., ProductionStatusWidget.js)

3. 📂 CATEGORY - Which folder in POD Designer?
   Options:
   • Custom        - Custom/user-defined widgets (DEFAULT - recommended for custom plugins)
   • Elements      - Basic UI elements (buttons, inputs, text, charts)
   • Layout        - Layout containers (panels, boxes, splitters)
   • WorkList      - Work list related widgets
   • Order         - Order-related widgets
   • SFC           - Shop Floor Control widgets
   • DataCollection - Data collection widgets
   • QuantityConfirmation - Quantity reporting widgets
   • ActivityConfirmation - Activity confirmation widgets
   • Assembly      - Assembly/component widgets (BOM, kitting)
   • GoodsReceipt  - Goods receipt widgets
   • Hidden        - Not shown in widget palette (for internal/dialog widgets)
   
   Default: Custom (if not specified)
   This determines where your widget appears in the POD Designer sidebar.
```

**Why These Are Critical:**

1. **Namespace**: Required for SAP DM upload, must match extension.json exactly
2. **Plugin Name**: Determines file names, class names, and widget identity
3. **Category**: Determines where users find your widget in POD Designer

### Workflow After Receiving Answers

1. **Validate namespace format** (e.g., `custom/pod2/project`)
2. **Convert namespace** for type field: slashes → dots (e.g., `custom.pod2.project`)
3. **Create file structure**: `widget/<PluginName>Widget.js`
4. **Set category** in `getCategory()` method: `return WidgetCategory.<Category>;`

### Converting Namespace Example

- **User provides**: `custom/pod2/myproject`
- **modulePath**: `custom/pod2/myproject/widget/ProductionStatusWidget`
- **type**: `custom.pod2.myproject.widget.ProductionStatusWidget`
- **File path**: `widget/ProductionStatusWidget.js`
- **Category**: `"Custom"` (default for custom plugins)

### Working Example - Real World Success

**User Input:**
```
1. Namespace: custom/pod2/three
2. Plugin Name: AnimationBlending
3. Category: Custom (or press Enter for default)
```

**Generated Files:**

**extension.json**:
```json
{
  "widgets": [{
    "modulePath": "custom/pod2/three/widget/AnimationBlendingWidget",
    "type": "custom.pod2.three.widget.AnimationBlendingWidget"
  }]
}
```

**widget/AnimationBlendingWidget.js**:
```javascript
class AnimationBlendingWidget extends Widget {
    static getDisplayName() {
        return "Animation Blending";
    }
    
    static getCategory() {
        return "Custom";  // ← Default for custom plugins
    }
    // ... rest of widget
}
```

**Zip structure** (three.zip):
```
three.zip
├── extension.json              # ✅ At root
└── widget/
    └── AnimationBlendingWidget.js
```

**Upload**: Enter namespace `custom/pod2/three` → Success!

**Key Points:**
- Namespace in extension.json MUST match upload namespace exactly
- Plugin name becomes class name with "Widget" suffix
- Category determines POD Designer placement

---

## 🚨 CRITICAL: Core POD 2.0 Rules

### 1. Binding Syntax - Where It Works vs. Doesn't
| Context | Binding `"{path}"` | Example |
|---------|-------------------|---------|
| ❌ WidgetProperty displayName/description | NOT ALLOWED | Use `this.getI18nText("key")` |
| ✅ getDefaultConfig() property values | ALLOWED | `headerText: "{i18n>title}"` |
| ✅ Control properties in _createView() | ALLOWED | `text: "{fieldName}"` |
| ✅ Expression binding | ALLOWED | `visible: "{= ${type} === 'TEXT' }"` |

### 2. Parent Property Spreading in getDefaultConfig()
| Base Class | Spread? | Why |
|------------|---------|-----|
| Widget | ❌ NO | Reserved SAPUI5 properties cause conflicts |
| ControlWidget | ❌ NO | Inherits Widget problems |
| TableWidget | ✅ YES | Essential defaults required |
| LayoutWidget | ✅ YES | Essential defaults required |

### 3. i18n Implementation (Framework-Driven)
```javascript
import I18nResourceModel from "sap/dm/dme/pod2/model/I18nResourceModel";

class YourWidget extends Widget {
    static #oI18nModel = new I18nResourceModel({
        bundleName: "your.namespace.i18n.i18n"  // Dots, not slashes!
    });
    
    static getI18nModel() { return this.#oI18nModel; }
    
    _createView() {
        return new Button({
            text: this.getI18nText("key")  // ✅ Method call, not binding!
        });
    }
}
```

**CRITICAL**: ALWAYS use `this.getI18nText()` in `_createView()`, NEVER `"{i18n>key}"` bindings.

**See**: [Common Mistakes](references/common-mistakes.md) for all errors with fixes.

---

## Quick Start (TL;DR)

### For POD 2.0 (Recommended):

**Step 0: Gather Required Information (REQUIRED FIRST!)**

Ask the user in a single prompt:
```
Before I create your plugin, I need three pieces of information:

1. 📦 NAMESPACE - What namespace? (e.g., custom/pod2/<projectname>)
   Default suggestion: custom/pod2/$(basename $(pwd))
   
2. 🏷️  PLUGIN NAME - What should it be called? (e.g., ProductionStatus)

3. 📂 CATEGORY - Which POD Designer folder?
   Options: Custom (default), Elements, Layout, WorkList, Order, SFC, 
            DataCollection, QuantityConfirmation, ActivityConfirmation, 
            Assembly, GoodsReceipt, Hidden
```

**Step 1: Choose your base class**
- Single control (button, input, text)? → **`ControlWidget`**
- Container for other widgets? → **`LayoutWidget`**
- Table with rows/columns? → **`TableWidget`**
- Business logic without UI? → **`ContentHandler`**

**Step 2: Implement these required methods**
```javascript
// Static metadata (REQUIRED)
static getDisplayName() { return "My Widget"; }
static getIcon() { return "sap-icon://factory"; }
static getCategory() { return "Custom"; }  // ← Default for custom plugins
static getIcon() { return "sap-icon://factory"; }
static getCategory() { return WidgetCategory.Elements; }

// Create view (REQUIRED)
_createView() {
    const oConfig = this.getConfig();
    // CRITICAL: Pass oConfig.id as FIRST parameter!
    return new VBox(oConfig.id, {
        items: [/* your controls */]
    });
}
```

**Step 3: Add i18n Support (Optional but Recommended)**

POD 2.0 framework automatically loads i18n models - you just provide the model via static method:

```javascript
import I18nResourceModel from "sap/dm/dme/pod2/model/I18nResourceModel";

class YourWidget extends Widget {
    
    // 1. Define static private i18n model
    static #oI18nModel = new I18nResourceModel({
        bundleName: "your.namespace.i18n.i18n"  // Use dots, not slashes!
    });
    
    // 2. Static getter for framework (framework calls this during widget registration)
    static getI18nModel() {
        return this.#oI18nModel;
    }
    
    // 3. ✅ ALWAYS use inherited getI18nText() method in _createView()
    _createView() {
        return new Button({
            text: this.getI18nText("myWidget.button")  // ✅ Method call works!
        });
    }
}
```

**🚨 CRITICAL i18n Rules:**
- ✅ **ALWAYS** use `this.getI18nText(key)` method calls in `_createView()`
- ❌ **NEVER** use binding syntax `"{i18n>key}"` in `_createView()` - model not ready yet!

**Step 4: File structure**
```
<working-directory-root>/     # User is already here
├── extension.json            # Generate at root
├── widget/                   # Create subfolder
│   └── YourWidget.js         # Widget file
└── i18n/                     # i18n subfolder  
    └── i18n_en.properties
```

**Step 5: Critical imports** (Use `context/` NOT `model/`!)
```javascript
"sap/dm/dme/pod2/context/PodContext"     // ✅ CORRECT
"sap/dm/dme/pod2/context/ModelPath"      // ✅ CORRECT
```

---

## POD 2.0 Architecture Overview

### Widget Class Hierarchy

```
Widget (abstract base - rarely extended directly)
├── ControlWidget (for single SAPUI5 controls)
│   └── Constructor pattern: super(SAPUI5ControlClass, oConfig)
├── LayoutWidget (for layout containers)
│   └── Constructor pattern: super(SAPUI5ControlClass, oConfig)
├── TableWidget (for complex data tables)
│   └── Requires: getFields(), getDefaultFields(), _createCell(), _getModelPath()
└── ContentHandler (business logic without UI)
    └── Used for: form processing, dialog logic, API workflows
```

### Widget Lifecycle

**POD 2.0 Widget Lifecycle Order:**
```
1. constructor(oConfig)     ← Widget instantiated
2. _createView()            ← UI created - MODEL MUST EXIST HERE!
3. onInit()                 ← Async initialization, subscriptions
4. [widget is rendered]
5. onExit()                 ← Cleanup when destroyed
```

**Critical Lifecycle Rule**: 
- Initialize JSONModels in `_createView()` BEFORE creating controls with bindings
- DO NOT initialize models in `onInit()` - it runs after `_createView()`!

---

## PodContext - Central State Management

```javascript
// Get current state
const sPlant = PodContext.getPlant();
const aResources = PodContext.get(ModelPath.FilterResources);
const oOperation = PodContext.get(ModelPath.CurrentOperation);

// Subscribe to changes (value FIRST, path SECOND)
PodContext.subscribe(ModelPath.FilterResources, (aResources, sPath) => {
    const resources = Array.isArray(aResources) ? aResources : [];
    // Handle resource change
}, this);

// Unsubscribe on cleanup
PodContext.unsubscribe(ModelPath.FilterResources, this._onResourceChanged, this);
```

**Critical Rule**: Callback signature is `(newValue, path)` NOT `(path, newValue)`!

---

## Complete Basic Example

**Step 1: Ask user for namespace**
```
Assistant: "What namespace would you like to use for this plugin?
            (e.g., custom/pod2/myproject, or acme/manufacturing)"

User: "custom/pod2/myawesomeplugin"
```

**Step 2: Create extension.json with user-provided namespace**
```json
{
  "widgets": [{
    "modulePath": "custom/pod2/myawesomeplugin/widget/BasicPlugin",
    "type": "custom.pod2.myawesomeplugin.widget.BasicPlugin"
  }],
  "actions": []
}
```

**Step 3: Widget implementation** - See full example in [references/widget-patterns.md](references/widget-patterns.md)

---

## Pre-Deployment Validation Checklist

Before creating the zip file, verify:

```bash
# 1. Ask user: "What namespace did you provide?" (e.g., "custom/pod2/myproject")
USER_NAMESPACE="custom/pod2/myproject"  # Example - use actual user response

# 2. Convert namespace for type field (slashes → dots)
TYPE_PREFIX=$(echo "$USER_NAMESPACE" | tr '/' '.')  # Result: custom.pod2.myproject

# 3. Check extension.json contains the correct namespace
grep "\"modulePath\": \"$USER_NAMESPACE/" extension.json
grep "\"type\": \"$TYPE_PREFIX." extension.json

# 4. Verify files exist at paths specified in extension.json
```

**Critical Rules:**
- Namespace in extension.json MUST match what user will enter during upload
- modulePath uses slashes: `custom/pod2/project/widget/MyWidget`
- type uses dots: `custom.pod2.project.widget.MyWidget`

---

## Creating Deployment Package

**CRITICAL**: When you finish creating or modifying a plugin, **ALWAYS create the deployment zip file automatically**.

### Automatic Zip Creation Steps

1. **Verify Structure First**
   ```bash
   ls -la
   # Should show: extension.json, widget/, action/, util/ at root level
   ```

2. **Create Zip File**
   
   **🚨 CRITICAL: Zip the CONTENTS of working directory - extension.json at zip root!**
   
   **Windows (PowerShell):**
   ```powershell
   $NAMESPACE = Split-Path -Leaf (Get-Location)
   Compress-Archive -Path extension.json,widget,action,i18n,util -DestinationPath "$NAMESPACE.zip" -Force
   ```
   
   **Mac/Linux:**
   ```bash
   NAMESPACE=$(basename $(pwd))
   zip -r "$NAMESPACE.zip" extension.json widget action i18n util
   ```
   
   **What this creates:**
   ```
   mycompany.zip
   ├── extension.json          # ✅ At zip root!
   ├── widget/
   │   └── MyWidget.js
   ├── action/
   │   └── MyAction.js
   └── util/
       └── Helper.js
   ```

3. **Verify Zip Contents**
   ```bash
   # Mac/Linux
   unzip -l mycompany.zip
   # First entry should be: extension.json (NOT mycompany/extension.json)
   ```

4. **Confirm to User**
   - ✅ Zip file location and name
   - ✅ Confirm correct structure (extension.json at root)
   - ✅ Ready for upload to Extension Center

---

## 🚨 CRITICAL: After Creating Plugin - Required Notifications

### 1. Plugin Information Summary Template

**ALWAYS include this summary after generating a POD 2.0 plugin:**

```
═══════════════════════════════════════════════════════════════
✅ PLUGIN CREATED SUCCESSFULLY
═══════════════════════════════════════════════════════════════

📦 PLUGIN DETAILS:

  🏷️  Plugin Name: [PluginName]Widget
  📋 Namespace: [user-provided-namespace]
  📂 Category: [Category] (appears in POD Designer under this folder)
  
  📂 Module Path: [user-provided-namespace]/widget/[PluginName]Widget
  🏷️  Type: [namespace-with-dots].widget.[PluginName]Widget

═══════════════════════════════════════════════════════════════
⚠️  CRITICAL - REQUIRED FOR UPLOAD
═══════════════════════════════════════════════════════════════

When uploading to SAP Digital Manufacturing Extension Center,
you will be asked to provide the namespace.

    USE THIS NAMESPACE: [user-provided-namespace]

This MUST MATCH the namespace in extension.json modulePath!

📝 Why This Matters:
   - SAP DM requires namespace during extension upload
   - Must match exactly what's in extension.json modulePath
   - Groups related plugins together
   - Prevents naming conflicts

⚠️  If the namespace doesn't match, upload will FAIL with error:
    "extension.json references files that do not start with 
    the correct namespace"

💾 Make note of this namespace before uploading!
═══════════════════════════════════════════════════════════════
```

---

### 2. AI-Generated Code Warning

**ALWAYS include this warning after generating ANY plugin code:**

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║  ⚠️  CRITICAL: AI-GENERATED CODE - MANUAL REVIEW REQUIRED                ║
║                                                                           ║
║  This plugin was generated by AI and MUST be thoroughly reviewed         ║
║  before use in any production environment.                               ║
║                                                                           ║
║  REQUIRED CHECKS BEFORE PRODUCTION USE:                                  ║
║                                                                           ║
║  ✅ Security Review                                                       ║
║     • Validate all API calls and authentication                          ║
║     • Check for injection vulnerabilities (SQL, XSS, etc.)               ║
║     • Review error handling and sensitive data exposure                  ║
║     • Verify input validation and sanitization                           ║
║                                                                           ║
║  ✅ Code Quality Review                                                   ║
║     • Verify business logic correctness                                  ║
║     • Check error handling and edge cases                                ║
║     • Review performance implications                                    ║
║     • Validate against company coding standards                          ║
║                                                                           ║
║  ✅ Functionality Testing                                                 ║
║     • Test all user interactions and workflows                           ║
║     • Verify integration with SAP DM APIs                                ║
║     • Test with real production data scenarios                           ║
║     • Validate PodContext subscriptions and data flow                    ║
║                                                                           ║
║  ⚠️  DO NOT deploy AI-generated code directly to production without      ║
║     thorough review by qualified developers and security team.           ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
```

---

## Pre-Generation Validation Checklist

**CRITICAL**: Before generating ANY widget code, verify:

### ✅ Import Validation

**1. PlacementType Import:**
```javascript
// ✅ CORRECT
import PlacementType from "sap/m/PlacementType";

// ❌ WRONG
// import coreLibrary from "sap/ui/core/library";
```

**2. PodContext & ModelPath Imports:**
```javascript
// ✅ CORRECT - Use context/ path
import PodContext from "sap/dm/dme/pod2/context/PodContext";
import ModelPath from "sap/dm/dme/pod2/context/ModelPath";

// ❌ WRONG - Don't use model/ path
```

### ✅ ModelPath Constants Validation

**CRITICAL**: Work list paths are PLURAL and return arrays!

```javascript
// ✅ CORRECT
ModelPath.SelectedWorkListItems   // Array (note plural!)
ModelPath.WorkListItems           // Array
ModelPath.FilterResources         // Array

// ❌ WRONG - These don't exist
// ModelPath.SelectedWorkListItem  // Doesn't exist!
```

### ✅ i18n Setup Validation

**Working pattern:**
```javascript
import ResourceModel from "sap/ui/model/resource/ResourceModel";

let oI18nModel = null;

class MyWidget extends Widget {
    static getI18nModel() {
        if (!oI18nModel) {
            oI18nModel = new ResourceModel({
                bundleName: "custom.company.project.i18n.i18n"  // Dots!
            });
        }
        return oI18nModel;
    }
}
```

### ✅ Base Class Selection

**Choose correct base to avoid view ID mismatch:**

| Base Class | Use For | Root Control |
|------------|---------|--------------|
| `Widget` | Complex layouts, custom views | Panel/VBox with `oConfig.id` |
| `ControlWidget` | Single control wrapper | Control passed to `super()` |
| `LayoutWidget` | Simple layout container | Control passed to `super()` |
| `TableWidget` | Data tables | Handled by base class |

### Quick Checklist

- [ ] **Base class**: Use `Widget` for complex layouts, not `LayoutWidget`
- [ ] **Root control ID**: EXACTLY `oConfig.id` (no suffix!)
- [ ] **i18n**: Use `ResourceModel` (not I18nResourceModel), static getter, model OUTSIDE class
- [ ] PlacementType from `"sap/m/PlacementType"`
- [ ] PodContext from `"sap/dm/dme/pod2/context/PodContext"`
- [ ] ModelPath constants are exact (SelectedWorkListItems not Item)
- [ ] **getDefaultConfig()**: NO spreading parent properties

---

## Reference Documentation

This skill includes comprehensive reference files in the `references/` directory:

### 📚 Core Framework Documentation
- **[pod2-api-reference.md](references/pod2-api-reference.md)** - Complete POD 2.0 framework API
- **[delegate-architecture.md](references/delegate-architecture.md)** ⭐ NEW - 8 official POD 2.0 delegates
- **[widget-patterns.md](references/widget-patterns.md)** - Widget implementation patterns
- **[advanced-patterns.md](references/advanced-patterns.md)** - 13 enterprise patterns
- **[production-patterns-unified.md](references/production-patterns-unified.md)** - 35 consolidated patterns
- **[common-mistakes.md](references/common-mistakes.md)** - All mistakes with fixes
- **[glossary.md](references/glossary.md)** - Key terms and definitions

### 🔌 SAP Digital Manufacturing API
- **[sapdm-api-reference.md](references/sapdm-api-reference.md)** - Complete SAP DM REST API reference
- **[api-specs/](references/api-specs/)** - Full OpenAPI/Swagger specifications

---

## Final Reminders

### 📋 Before Generation (STEP 0 - CRITICAL!)
1. ✅ **ALWAYS** ask for THREE pieces of information:
   - **Namespace** (hierarchical, e.g., "custom/pod2/project")
   - **Plugin Name** (e.g., "ProductionStatus", "QualityInspection")
   - **Category** (e.g., Elements, WorkList, DataCollection, etc.)
2. ✅ **Use exact user-provided values** in all generated files
3. ✅ **Convert namespace** for type field: slashes → dots

### 🔧 Code Generation Rules
4. ✅ **Always** use `context/` import path, NOT `model/`
5. ✅ **Never** use binding syntax in WidgetProperty
6. ✅ **Never** spread parent properties in getDefaultConfig()
7. ✅ **Root control ID** MUST be exactly `oConfig.id`
8. ✅ **Use base `Widget` class** for complex layouts
9. ✅ **Use `ResourceModel`** for i18n, with static getter outside class
10. ✅ **Always** validate types (use `Array.isArray()`)
11. ✅ **Always** unsubscribe from PodContext in onExit()

### 📦 After Generation (Automatic!)
12. ✅ **Create deployment zip file** automatically when plugin is complete
13. ✅ **Display namespace notification** after creating plugin
14. ✅ **Display AI-generated code warning** after creating ANY plugin code

📖 **For detailed help**, consult the reference documentation files above.
