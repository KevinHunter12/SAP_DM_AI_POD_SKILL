#!/usr/bin/env python3
"""
Script to reorganize pod-plugin SKILL.md into modular reference files.
Extracts sections from the massive 4,317-line file into smaller, focused files.
"""

import re
import os
from pathlib import Path

# Define section extraction rules
EXTRACTIONS = {
    "references/common-mistakes.md": {
        "start": "## Top 10 Mistakes",
        "end": "## Decision Tree",
        "title": "# Common Mistakes and Fixes\n\nComplete guide to the most common POD plugin development mistakes and their solutions.\n\n"
    },
    "references/pod-1-legacy.md": {
        "start": "## POD 1.0 Architecture",
        "end": "## Migration Path",
        "title": "# POD 1.0 Legacy Architecture\n\nComplete documentation for POD 1.0 (legacy component-based architecture).\n\n"
    },
    "references/widget-patterns.md": {
        "start": "## ControlWidget Pattern",
        "end": "## Common Issues and Solutions",
        "title": "# Widget Patterns Reference\n\nDetailed patterns for ControlWidget, LayoutWidget, and TableWidget.\n\n"
    },
    "references/api-guide.md": {
        "start": "### POD 2.0 API Calls",
        "end": "## Testing Your Plugin",
        "title": "# API Guide\n\nComplete guide to RestClient and ApiClient usage.\n\n"
    },
    "references/pod-context.md": {
        "start": "### POD 2.0 Context Access",
        "end": "### POD 2.0 Lifecycle Methods",
        "title": "# PodContext Reference\n\nComplete guide to PodContext, ModelPath, and state management.\n\n"
    }
}

def extract_section(content, start_marker, end_marker):
    """Extract content between start and end markers."""
    lines = content.split('\n')
    extracting = False
    extracted = []

    for line in lines:
        if start_marker in line:
            extracting = True

        if extracting:
            extracted.append(line)

        if end_marker in line and extracting and line != start_marker:
            break

    return '\n'.join(extracted)

def main():
    skill_path = Path(__file__).parent / "SKILL.md"
    refs_dir = Path(__file__).parent / "references"

    # Read original file
    with open(skill_path, 'r', encoding='utf-8') as f:
        content = f.read()

    print(f"Original SKILL.md: {len(content.split(chr(10)))} lines")

    # Create references directory
    refs_dir.mkdir(exist_ok=True)

    # Extract sections
    for filename, config in EXTRACTIONS.items():
        output_path = Path(__file__).parent / filename
        section_content = extract_section(content, config["start"], config["end"])

        if section_content:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(config["title"])
                f.write(section_content)

            lines = len(section_content.split('\n'))
            print(f"Created {filename}: {lines} lines")
        else:
            print(f"Warning: Could not extract {filename}")

    print("\nExtraction complete!")
    print("Next: Manually create streamlined SKILL.md")

if __name__ == "__main__":
    main()
